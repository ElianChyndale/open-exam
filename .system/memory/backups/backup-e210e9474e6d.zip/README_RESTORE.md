# OpenExam Backup Restore

Export mode: safe

Validate checksums before restore. This archive is data-only; do not execute contents.
Safe exports redact raw wrong-answer and internal diagnostic fields.
